package com.example.admin.gestureswiper;

import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.TextView;
import android.view.GestureDetector;
import android.support.v4.view.GestureDetectorCompat;



public class MainActivity extends ActionBarActivity implements GestureDetector.OnGestureListener,GestureDetector.OnDoubleTapListener
{
    private TextView msg;
    private GestureDetectorCompat gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        msg = (TextView)findViewById(R.id.text1);
        this.gestureDetector = new GestureDetectorCompat(this,this);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent)
    {
        msg.setText("Single Tap");
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent)
    {
        msg.setText("DoubleTap");
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent)
    {
        msg.setText("Double tap event");
        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent)
    {
        msg.setText("Down");
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent)
    {
        msg.setText("Show press");
    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent)
    {
        msg.setText("Single tpa up");
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1)
    {
        msg.setText("on Scroll");
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent)
    {
        msg.setText("Long Press");
    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1)
    {
        msg.setText("Fling!!");
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        this.gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }
}
